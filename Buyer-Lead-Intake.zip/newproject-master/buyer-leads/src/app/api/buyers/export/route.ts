import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { stringify } from "csv-stringify/sync";

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const city = searchParams.get("city");

    const buyers = await prisma.buyer.findMany({
        where: city ? { city: city as any } : {},
        orderBy: { updatedAt: "desc" },
    });

    const records = buyers.map((b) => ({
        fullName: b.fullName,
        email: b.email,
        phone: b.phone,
        city: b.city,
        propertyType: b.propertyType,
        bhk: b.bhk,
        purpose: b.purpose,
        budgetMin: b.budgetMin,
        budgetMax: b.budgetMax,
        timeline: b.timeline,
        source: b.source,
        notes: b.notes,
        tags: b.tags.join(","),
        status: b.status,
    }));

    const csv = stringify(records, { header: true });
    return new NextResponse(csv, {
        headers: {
            "Content-Type": "text/csv",
            "Content-Disposition": "attachment; filename=buyers.csv",
        },
    });
}
