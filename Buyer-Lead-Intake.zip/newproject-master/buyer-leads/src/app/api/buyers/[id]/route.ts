import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET(
    req: Request,
    { params }: { params: Promise<{ id: string }> }
) {
    const { id } = await params;
    const buyer = await prisma.buyer.findUnique({ where: { id } });

    if (!buyer) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(buyer);
}

export async function PATCH(
    req: Request,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        const body = await req.json();

        // Strip out uneditable fields
        const { id: _id, createdAt, updatedAt, history, ...updateData } = body;

        const buyer = await prisma.buyer.update({
            where: { id },
            data: updateData,
        });

        await prisma.buyerHistory.create({
            data: {
                buyerId: id,
                changedBy: "demo-user",
                diff: updateData,
            },
        });

        return NextResponse.json(buyer);
    } catch (err) {
        console.error("PATCH /buyers/:id error:", err);
        return NextResponse.json({ error: "Failed to update buyer" }, { status: 500 });
    }
}

export async function DELETE(
    req: Request,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        await prisma.buyer.delete({ where: { id } });
        return NextResponse.json({ success: true });
    } catch (err) {
        console.error("DELETE /buyers/:id error:", err);
        return NextResponse.json({ error: "Failed to delete buyer" }, { status: 500 });
    }
}
