"use client";

import { useState } from "react";

export default function NewBuyerPage() {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState(false);

    async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();
        setError(null);
        setSuccess(false);
        setLoading(true);

        const formData = new FormData(e.currentTarget);
        const data = Object.fromEntries(formData.entries());

        try {
            const res = await fetch("/api/buyers", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data),
            });

            if (!res.ok) {
                const err = await res.json();
                throw new Error(err.error ?? "Failed to create buyer");
            }

            setSuccess(true);
            e.currentTarget.reset();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    }

    return (
        <div className="max-w-2xl mx-auto p-6">
            <h1 className="text-2xl font-bold mb-4">Create New Buyer</h1>

            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block">Full Name</label>
                    <input name="fullName" required className="border p-2 w-full" />
                </div>

                <div>
                    <label className="block">Email</label>
                    <input type="email" name="email" className="border p-2 w-full" />
                </div>

                <div>
                    <label className="block">Phone</label>
                    <input name="phone" required className="border p-2 w-full" />
                </div>

                <div>
                    <label className="block">City</label>
                    <select name="city" className="border p-2 w-full" required>
                        <option value="Chandigarh">Chandigarh</option>
                        <option value="Mohali">Mohali</option>
                        <option value="Zirakpur">Zirakpur</option>
                        <option value="Panchkula">Panchkula</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div>
                    <label className="block">Property Type</label>
                    <select name="propertyType" className="border p-2 w-full" required>
                        <option value="Apartment">Apartment</option>
                        <option value="Villa">Villa</option>
                        <option value="Plot">Plot</option>
                        <option value="Office">Office</option>
                        <option value="Retail">Retail</option>
                    </select>
                </div>

                <div>
                    <label className="block">Purpose</label>
                    <select name="purpose" className="border p-2 w-full" required>
                        <option value="Buy">Buy</option>
                        <option value="Rent">Rent</option>
                    </select>
                </div>

                <div className="flex gap-4">
                    <div className="flex-1">
                        <label className="block">Budget Min</label>
                        <input type="number" name="budgetMin" className="border p-2 w-full" />
                    </div>
                    <div className="flex-1">
                        <label className="block">Budget Max</label>
                        <input type="number" name="budgetMax" className="border p-2 w-full" />
                    </div>
                </div>

                <div>
                    <label>Timeline</label>
                    <select {...register("timeline")} className="border p-2 rounded">
                        <option value="ZERO_TO_3M">0-3 months</option>
                        <option value="THREE_TO_6M">3-6 months</option>
                        <option value="GT_6M">More than 6 months</option>
                        <option value="EXPLORING">Exploring</option>
                    </select>
                </div>
                <div>
                    <label>BHK</label>
                    <select {...register("bhk")} className="border p-2 rounded">
                        <option value="">Select</option>
                        <option value="ONE">1</option>
                        <option value="TWO">2</option>
                        <option value="THREE">3</option>
                        <option value="FOUR">4</option>
                        <option value="STUDIO">Studio</option>
                    </select>
                </div>

                <div>
                    <label>Source</label>
                    <select {...register("source")} className="border p-2 rounded">
                        <option value="Website">Website</option>
                        <option value="Referral">Referral</option>
                        <option value="Walk_in">Walk-in</option>
                        <option value="Call">Call</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div>
                    <label className="block">Notes</label>
                    <textarea name="notes" className="border p-2 w-full" maxLength={1000}></textarea>
                </div>

                <button
                    type="submit"
                    disabled={loading}
                    className="bg-blue-600 text-white px-4 py-2 rounded"
                >
                    {loading ? "Saving..." : "Create Buyer"}
                </button>

                {error && <p className="text-red-600">{error}</p>}
                {success && <p className="text-green-600">Buyer created successfully!</p>}
            </form>
        </div>
    );
}
