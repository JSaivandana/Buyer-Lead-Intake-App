import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { z } from "zod";
import { buyerCreateSchema} from "@/lib/validations/buyer";
// ------------------ Zod Schemas ------------------

// Create/update buyer schema
const buyerSchema = z.object({
    fullName: z.string().min(2).max(80),
    email: z.string().email().optional(),
    phone: z.string().regex(/^\d{10,15}$/),
    city: z.enum(["Chandigarh", "Mohali", "Zirakpur", "Panchkula", "Other"]),
    propertyType: z.enum(["Apartment", "Villa", "Plot", "Office", "Retail"]),
    bhk: z.enum(["1", "2", "3", "4", "Studio"]).optional(),
    purpose: z.enum(["Buy", "Rent"]),
    budgetMin: z.number().int().optional(),
    budgetMax: z.number().int().optional(),
    timeline: z.enum(["0-3m", "3-6m", ">6m", "Exploring"]),
    source: z.enum(["Website", "Referral", "Walk-in", "Call", "Other"]),
    status: z.enum([
        "New",
        "Qualified",
        "Contacted",
        "Visited",
        "Negotiation",
        "Converted",
        "Dropped",
    ]).default("New"),
    notes: z.string().max(1000).optional(),
    tags: z.array(z.string()).optional(),
});

// Query schema for filters/pagination
const listQuerySchema = z.object({
    page: z.coerce.number().int().min(1).default(1),
    pageSize: z.coerce.number().int().min(1).max(100).default(10),
    city: z.enum(["Chandigarh", "Mohali", "Zirakpur", "Panchkula", "Other"]).optional(),
    propertyType: z.enum(["Apartment", "Villa", "Plot", "Office", "Retail"]).optional(),
    status: z.enum([
        "New",
        "Qualified",
        "Contacted",
        "Visited",
        "Negotiation",
        "Converted",
        "Dropped",
    ]).optional(),
    timeline: z.enum(["0-3m", "3-6m", ">6m", "Exploring"]).optional(),
    search: z.string().optional(),
});

// ------------------ Handlers ------------------

// GET /api/buyers
export async function GET(req: Request) {
    const url = new URL(req.url);

    const parsed = listQuerySchema.parse({
        page: url.searchParams.get("page") ?? undefined,
        pageSize: url.searchParams.get("pageSize") ?? undefined,
        city: url.searchParams.get("city") ?? undefined,
        propertyType: url.searchParams.get("propertyType") ?? undefined,
        status: url.searchParams.get("status") ?? undefined,
        timeline: url.searchParams.get("timeline") ?? undefined,
        search: url.searchParams.get("search") ?? undefined,
    });

    const skip = (parsed.page - 1) * parsed.pageSize;

    const where: any = {};
    if (parsed.city) where.city = parsed.city;
    if (parsed.propertyType) where.propertyType = parsed.propertyType;
    if (parsed.status) where.status = parsed.status;
    if (parsed.timeline) where.timeline = parsed.timeline;
    if (parsed.search) {
        where.OR = [
            { fullName: { contains: parsed.search, mode: "insensitive" } },
            { email: { contains: parsed.search, mode: "insensitive" } },
            { phone: { contains: parsed.search, mode: "insensitive" } },
        ];
    }

    const [buyers, total] = await Promise.all([
        prisma.buyer.findMany({
            where,
            skip,
            take: parsed.pageSize,
            orderBy: { updatedAt: "desc" },
        }),
        prisma.buyer.count({ where }),
    ]);

    return NextResponse.json({
        data: buyers,
        pagination: {
            page: parsed.page,
            pageSize: parsed.pageSize,
            total,
            totalPages: Math.ceil(total / parsed.pageSize),
        },
    });
}

// POST /api/buyers
export async function POST(req: Request) {
    try {
        const body = await req.json();

        const parsed = buyerCreateSchema.parse(body);

        const buyer = await prisma.buyer.create({
            data: {
                ...parsed,
                ownerId: "demo-user", // replace with logged-in user later
            },
        });

        return NextResponse.json(buyer, { status: 201 });
    } catch (err) {
        if (err instanceof z.ZodError) {
            return NextResponse.json({ errors: err.errors }, { status: 400 });
        }
        console.error(err);
        return NextResponse.json({ error: "Server error" }, { status: 500 });
    }
}


// PATCH /api/buyers/:id
export async function PATCH(req: Request) {
    try {
        const url = new URL(req.url);
        const id = url.searchParams.get("id");
        if (!id) return NextResponse.json({ error: "Missing buyer id" }, { status: 400 });

        const body = await req.json();
        const parsed = buyerSchema.partial().safeParse(body);

        if (!parsed.success) {
            return NextResponse.json({ error: parsed.error.format() }, { status: 400 });
        }

        const existing = await prisma.buyer.findUnique({ where: { id } });
        if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

        const buyer = await prisma.buyer.update({
            where: { id },
            data: { ...parsed.data },
        });

        await prisma.buyerHistory.create({
            data: {
                buyerId: buyer.id,
                changedBy: "demo-user",
                diff: parsed.data,
            },
        });

        return NextResponse.json(buyer);
    } catch (err) {
        console.error(err);
        return NextResponse.json({ error: "Failed to update buyer" }, { status: 500 });
    }
}

// DELETE /api/buyers/:id
export async function DELETE(req: Request) {
    try {
        const url = new URL(req.url);
        const id = url.searchParams.get("id");
        if (!id) return NextResponse.json({ error: "Missing buyer id" }, { status: 400 });

        await prisma.buyer.delete({ where: { id } });
        return NextResponse.json({ success: true });
    } catch (err) {
        console.error(err);
        return NextResponse.json({ error: "Failed to delete buyer" }, { status: 500 });
    }
}
