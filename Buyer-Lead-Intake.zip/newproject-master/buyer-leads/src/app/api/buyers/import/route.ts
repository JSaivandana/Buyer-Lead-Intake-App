import { NextResponse } from "next/server";
import { parse } from "csv-parse/sync";
import { prisma } from "@/lib/db";
import { z } from "zod";

const rowSchema = z.object({
    fullName: z.string().min(2).max(80),
    email: z.string().email().optional(),
    phone: z.string().regex(/^\d{10,15}$/),
    city: z.enum(["Chandigarh", "Mohali", "Zirakpur", "Panchkula", "Other"]),
    propertyType: z.enum(["Apartment", "Villa", "Plot", "Office", "Retail"]),
    bhk: z.enum(["Studio", "One", "Two", "Three", "Four"]).optional(),
    purpose: z.enum(["Buy", "Rent"]),
    budgetMin: z.string().optional(),
    budgetMax: z.string().optional(),
    timeline: z.enum(["0-3m", "3-6m", ">6m", "Exploring"]),
    source: z.enum(["Website", "Referral", "Walk-in", "Call", "Other"]),
    notes: z.string().max(1000).optional(),
    tags: z.string().optional(),
    status: z.enum(["New", "Qualified", "Contacted", "Visited", "Negotiation", "Converted", "Dropped"]).optional(),
});

export async function POST(req: Request) {
    try {
        const text = await req.text();
        const records = parse(text, { columns: true, skip_empty_lines: true });

        if (records.length > 200) {
            return NextResponse.json({ error: "Max 200 rows allowed" }, { status: 400 });
        }

        const errors: { row: number; message: string }[] = [];
        const validRows: any[] = [];

        records.forEach((row: any, i: number) => {
            const parsed = rowSchema.safeParse(row);
            if (!parsed.success) {
                errors.push({ row: i + 1, message: JSON.stringify(parsed.error.format()) });
            } else {
                validRows.push({
                    ...parsed.data,
                    budgetMin: parsed.data.budgetMin ? parseInt(parsed.data.budgetMin) : null,
                    budgetMax: parsed.data.budgetMax ? parseInt(parsed.data.budgetMax) : null,
                    tags: parsed.data.tags ? parsed.data.tags.split(",").map((t) => t.trim()) : [],
                    ownerId: "demo-user",
                });
            }
        });

        if (errors.length) {
            return NextResponse.json({ errors }, { status: 400 });
        }

        const result = await prisma.$transaction(
            validRows.map((row) => prisma.buyer.create({ data: row }))
        );

        return NextResponse.json({ inserted: result.length });
    } catch (err) {
        console.error(err);
        return NextResponse.json({ error: "Failed import" }, { status: 500 });
    }
}
