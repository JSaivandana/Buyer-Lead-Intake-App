"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

export default function BuyerDetailPage() {
    const { id } = useParams() as { id: string };
    const [buyer, setBuyer] = useState<any>(null);
    const [form, setForm] = useState<any>({});
    const [error, setError] = useState("");

    useEffect(() => {
        fetch(`/api/buyers/${id}`).then((r) => r.json()).then(setBuyer);
    }, [id]);

    useEffect(() => {
        if (buyer) setForm(buyer);
    }, [buyer]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSave = async () => {
        const res = await fetch(`/api/buyers/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(form),
        });
        if (!res.ok) {
            setError("Record changed or error updating. Please refresh.");
        } else {
            const updated = await res.json();
            setBuyer(updated);
            alert("Saved!");
        }
    };

    if (!buyer) return <div>Loading...</div>;

    return (
        <div className="p-6 space-y-4">
            <h1 className="text-xl font-bold">Edit Buyer</h1>
            {error && <div className="text-red-500">{error}</div>}

            <input
                name="fullName"
                value={form.fullName || ""}
                onChange={handleChange}
                className="border p-2 w-full"
            />

            <input
                name="phone"
                value={form.phone || ""}
                onChange={handleChange}
                className="border p-2 w-full"
            />

            <button onClick={handleSave} className="bg-blue-600 text-white px-4 py-2 rounded">
                Save
            </button>

            <h2 className="text-lg font-bold mt-6">History</h2>
            <ul className="list-disc pl-6">
                {buyer.history?.map((h: any) => (
                    <li key={h.id}>
                        <span className="text-sm">{new Date(h.changedAt).toLocaleString()}</span> –{" "}
                        {JSON.stringify(h.diff)}
                    </li>
                ))}
            </ul>
        </div>
    );
}
