"use client";

import useSWR from "swr";

const fetcher = (url: string) => fetch(url).then((r) => r.json());

export default function BuyersList() {
    const { data, error } = useSWR("/api/buyers?page=1", fetcher);

    if (error) return <div>Error loading buyers</div>;
    if (!data) return <div>Loading...</div>;

    return (
        <div className="p-4">
            <h1 className="text-xl font-bold mb-4">Buyers</h1>
            <table className="border w-full">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Property Type</th>
                    <th>Status</th>
                    <th>Updated At</th>
                </tr>
                </thead>
                <tbody>
                {data.map((b: any) => (
                    <tr key={b.id}>
                        <td>{b.fullName}</td>
                        <td>{b.phone}</td>
                        <td>{b.city}</td>
                        <td>{b.propertyType}</td>
                        <td>{b.status}</td>
                        <td>{new Date(b.updatedAt).toLocaleString()}</td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
}
