"use client";

import { useState } from "react";

export default function NewBuyerPage() {
    const [form, setForm] = useState({
        fullName: "",
        phone: "",
        city: "Chandigarh",
        propertyType: "Apartment",
        purpose: "Buy",
        timeline: "0-3m",
        source: "Website",
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const res = await fetch("/api/buyers", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(form),
        });
        if (res.ok) {
            alert("Buyer created!");
        } else {
            alert("Error creating buyer");
        }
    };

    return (
        <form onSubmit={handleSubmit} className="p-4 max-w-lg mx-auto space-y-4">
            <h1 className="text-xl font-bold">New Buyer</h1>
            <input
                name="fullName"
                value={form.fullName}
                onChange={handleChange}
                placeholder="Full Name"
                className="border p-2 w-full"
                required
            />
            <input
                name="phone"
                value={form.phone}
                onChange={handleChange}
                placeholder="Phone"
                className="border p-2 w-full"
                required
            />
            <select name="city" value={form.city} onChange={handleChange} className="border p-2 w-full">
                <option>Chandigarh</option>
                <option>Mohali</option>
                <option>Zirakpur</option>
                <option>Panchkula</option>
                <option>Other</option>
            </select>
            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
                Save
            </button>
        </form>
    );
}
