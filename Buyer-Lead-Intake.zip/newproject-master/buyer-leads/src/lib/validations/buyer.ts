import { z } from "zod";

export const buyerCreateSchema = z
    .object({
        fullName: z.string().min(2).max(80),
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().regex(/^\d{10,15}$/, "Phone must be 10–15 digits"),
        city: z.enum(["Chandigarh", "Mohali", "Zirakpur", "Panchkula", "Other"]),
        propertyType: z.enum([
            "Apartment",
            "Villa",
            "Plot",
            "Office",
            "Retail",
        ]),
        bhk: z.enum(["ONE", "TWO", "THREE", "FOUR", "STUDIO"]).optional(),
        purpose: z.enum(["Buy", "Rent"]),
        budgetMin: z.coerce.number().int().positive().optional(),
        budgetMax: z.coerce.number().int().positive().optional(),
        timeline: z.enum(["ZERO_TO_3M", "THREE_TO_6M", "GT_6M", "EXPLORING"]),
        source: z.enum(["Website", "Referral", "Walk_in", "Call", "Other"]),
        status: z
            .enum([
                "New",
                "Qualified",
                "Contacted",
                "Visited",
                "Negotiation",
                "Converted",
                "Dropped",
            ])
            .default("New"),
        notes: z.string().max(1000).optional(),
        tags: z.array(z.string()).optional(),
    })
    // bhk required only if Apartment or Villa
    .refine(
        (data) =>
            !["Apartment", "Villa"].includes(data.propertyType) || data.bhk,
        {
            message: "BHK is required for Apartment or Villa",
            path: ["bhk"],
        }
    )
    // budgetMax must be >= budgetMin
    .refine(
        (data) =>
            data.budgetMin == null ||
            data.budgetMax == null ||
            data.budgetMax >= data.budgetMin,
        {
            message: "budgetMax must be greater than or equal to budgetMin",
            path: ["budgetMax"],
        }
    );
